# TP2 R3.07 – JDBC 
**Nom : Weis**  
**Prénom : Marin**
**Groupe : C1**

## Choix techniques

J’ai créé une base de données PostgreSQL lancée dans Docker pour séparer proprement l’environnement de développement. J’ai utilisé un fichier .env pour sécuriser les informations sensibles comme l’URL, le mot de passe et l’utilisateur de la base. J’ai ajouté progressivement les contraintes avec ALTER TABLE pour rendre la base plus robuste sans la recréer entièrement. J’ai utilisé JDBC avec des PreparedStatement afin d’éviter les injections SQL et j’ai ajouté une table associative Compte_Client pour gérer la relation entre les comptes et les clients. J’ai aussi mis en place des transactions pour sécuriser les insertions et éviter les incohérences. J’ai structuré la classe BanqueDAO avec des méthodes claires pour chaque insertion et une gestion propre des erreurs SQL. Enfin, j’ai intégré Log4J2 pour tracer les opérations, faciliter le débogage et améliorer la maintenabilité.

## Difficultés rencontrées

J’ai d’abord rencontré des erreurs liées à Docker car les scripts SQL n’étaient pas correctement montés dans le conteneur. J’ai corrigé cela en ajustant les volumes et en nettoyant le dossier des données pour forcer PostgreSQL à réexécuter les scripts. Ensuite, j’ai eu plusieurs erreurs SQL de contraintes notamment sur les dates ou les ages parce que les types ne correspondaient pas ou que les CHECK bloquaient certaines valeurs. J’ai aussi eu des problèmes de violation de clé primaire lors des tests répétés, que j’ai résolus en implémentant une méthode resetDatabase qui vide proprement les tables. La mise en place de la table associative a aussi demandé des ajustements car il fallait respecter l’ordre des insertions et gérer les doublons. Enfin, j’ai dû ajuster les transactions et les exceptions pour que le programme reste stable même en cas d’erreur.
