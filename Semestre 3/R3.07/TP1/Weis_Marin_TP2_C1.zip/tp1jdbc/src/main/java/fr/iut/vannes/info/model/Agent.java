package fr.iut.vannes.info.model;


/**
 * Classe Agent représentant un agent dans le système bancaire.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class Agent {
    
    private int numAgent;
    private String nomAgent;
    private String prenomAgent;
    private boolean estDirecteur;
    private int numAgence;

    /**
     * Constructeur de la classe Agent.
     * @param numAgent
     * @param nomAgent
     * @param prenomAgent
     * @param estDirecteur
     * @param numAgence
     */
    public Agent(int numAgent, String nomAgent, String prenomAgent, boolean estDirecteur, int numAgence) {
        this.numAgent = numAgent;
        this.nomAgent = nomAgent;
        this.prenomAgent = prenomAgent;
        this.estDirecteur = estDirecteur;
        this.numAgence = numAgence;
    }

    // Getters et Setters

    /**
     * Getter pour le numéro de l'agent.
     * @return
     */
    public int getNumAgent() {
        return numAgent;
    }

    /**
     * Setter pour le numéro de l'agent.
     * @param numAgent
     */
    public void setNumAgent(int numAgent) {
        this.numAgent = numAgent;
    }

    /**
     * Getter pour le nom de l'agent.
     * @return
     */
    public String getNomAgent() {
        return nomAgent;
    }

    /**
     * Setter pour le nom de l'agent.
     * @param nomAgent
     */
    public void setNomAgent(String nomAgent) {
        this.nomAgent = nomAgent;
    }

    /**
     * Getter pour le prénom de l'agent.
     * @return
     */
    public String getPrenomAgent() {
        return prenomAgent;
    }

    /**
     * Setter pour le prénom de l'agent.
     * @param prenomAgent
     */
    public void setPrenomAgent(String prenomAgent) {
        this.prenomAgent = prenomAgent;
    }

    /**
     * Getter pour savoir si l'agent est directeur.
     * @return
     */
    public boolean isEstDirecteur() {
        return estDirecteur;
    }

    /**
     * Setter pour savoir si l'agent est directeur.
     * @param estDirecteur
     */
    public void setEstDirecteur(boolean estDirecteur) {
        this.estDirecteur = estDirecteur;
    }

    /**
     * Getter pour le numéro de l'agence associée à l'agent.
     * @return
     */
    public int getNumAgence() {
        return numAgence;
    }

    /**
     * Setter pour le numéro de l'agence associée à l'agent.
     * @param numAgence
     */
    public void setNumAgence(int numAgence) {
        this.numAgence = numAgence;
    }
}
