package fr.iut.vannes.info.model;


/**
 * Classe Compte représentant un compte bancaire dans le système.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class Compte {

    private int numCompte;
    private float solde;
    private String typeCompte;
    
    /**
     * Constructeur de la classe Compte.
     * @param numCompte
     * @param solde
     * @param typeCompte
     */
    public Compte(int numCompte, float solde, String typeCompte) {
        this.numCompte = numCompte;
        this.solde = solde;
        this.typeCompte = typeCompte;
    }

    // Getters et Setters

    /**
     * Getter pour le numéro du compte.
     * @return
     */
    public int getNumCompte() {
        return numCompte;
    }

    /**
     * Setter pour le numéro du compte.
     * @param numCompte
     */
    public void setNumCompte(int numCompte) {
        this.numCompte = numCompte;
    }

    /**
     * Getter pour le solde du compte.
     * @return
     */
    public float getSolde() {
        return solde;
    }

    /**
     * Setter pour le solde du compte.
     * @param solde
     */
    public void setSolde(float solde) {
        this.solde = solde;
    }

    /**
     * Getter pour le type du compte.
     * @return
     */
    public String getTypeCompte() {
        return typeCompte;
    }

    /**
     * Setter pour le type du compte.
     * @param typeCompte
     */
    public void setTypeCompte(String typeCompte) {
        this.typeCompte = typeCompte;
    }
}
