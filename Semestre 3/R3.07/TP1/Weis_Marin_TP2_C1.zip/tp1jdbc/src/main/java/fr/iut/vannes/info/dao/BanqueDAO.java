package fr.iut.vannes.info.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import fr.iut.vannes.info.model.Agence;
import fr.iut.vannes.info.model.Agent;
import fr.iut.vannes.info.model.Client;
import fr.iut.vannes.info.model.Operation;
import fr.iut.vannes.info.model.Compte;
import fr.iut.vannes.info.model.CompteClient;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Classe BanqueDAO pour gérer les opérations de la base de données bancaire.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class BanqueDAO {
    private static final Logger logger = LogManager.getLogger(BanqueDAO.class);
    private Connection connection;

    /**
     * Constructeur de la classe BanqueDAO
     * @param connection
     */
    public BanqueDAO(Connection connection) {
        this.connection = connection;
        logger.info("Initialisation de BanqueDAO avec une nouvelle connexion");
    }

    /**
     * Méthode pour se connecter au serveur de donnees
     * @return Connection
     * @throws SQLException
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
            System.getenv("DB_URL"),
            System.getenv("DB_USER"),
            System.getenv("DB_PASSWORD")
        );
    }

    /**
     * Méthode pour ajouter une agence
     * @param agence
     * @throws SQLException
     */
    public void ajouterAgence(Agence agence) throws SQLException {
        String sql = "INSERT INTO Agence (numAgence, telAgence, adAgence) VALUES (?, ?, ?)";
        logger.debug("Tentative d'ajout de l'agence : {}", agence.getNumAgence());
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, agence.getNumAgence());
            pstmt.setString(2, agence.getTelAgence());
            pstmt.setString(3, agence.getAdAgence());
            pstmt.executeUpdate();
        }
    }

    /**
     * Méthode pour ajouter un agent
     * @param agent
     * @throws SQLException
     */
    public void ajouterAgent(Agent agent) throws SQLException {
        String query = "INSERT INTO Agent (numAgent, nomAgent, prenomAgent, estDirecteur, numAgence) VALUES (?, ?, ?, ?, ?)";
        logger.debug("Tentative d'ajout de l'agent : {}", agent.getNumAgent());
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, agent.getNumAgent());
            pstmt.setString(2, agent.getNomAgent());
            pstmt.setString(3, agent.getPrenomAgent());
            pstmt.setBoolean(4, agent.isEstDirecteur());
            pstmt.setInt(5, agent.getNumAgence());
            pstmt.executeUpdate();
        }
    }

    /**
     * Méthode pour ajouter un client
     * @param client
     * @throws SQLException
     */
    public void ajouterClient(Client client) throws SQLException {
        String query = "INSERT INTO Client (numClient, nomClient, prenomClient, adClient, dateNaissClient, ageClient, numAgent) VALUES (?, ?, ?, ?, ?, ?, ?)";
        logger.debug("Tentative d'ajout du client : {}", client.getNumClient());
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, client.getNumClient());
            pstmt.setString(2, client.getNomClient());
            pstmt.setString(3, client.getPrenomClient());
            pstmt.setString(4, client.getAdClient());
            pstmt.setDate(5, java.sql.Date.valueOf(client.getDateNaissClient()));
            pstmt.setInt(6, client.getAgeClient());
            pstmt.setInt(7, client.getNumAgent());
            pstmt.executeUpdate();
        }
    }

    /**
     * Méthode pour ajouter un compte
     * @param compte
     * @throws SQLException
     */
    public void ajouterCompte(Compte compte) throws SQLException {
        String query = "INSERT INTO Compte (numCompte, solde, typeCompte) VALUES (?, ?, ?)";
        logger.debug("Tentative d'ajout du compte : {}", compte.getNumCompte());
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, compte.getNumCompte());
            pstmt.setFloat(2, compte.getSolde());
            pstmt.setString(3, compte.getTypeCompte());
            pstmt.executeUpdate();
        }
    }

    /**
     * Méthode pour ajouter une operation
     * @param operation
     * @throws SQLException
     */
    public void ajouterOperation(Operation operation) throws SQLException {
        String query = "INSERT INTO Operation (numOperation, dateOperation, typeOperation, montant, numCompte) VALUES (?, ?, ?, ?, ?)";
        logger.debug("Tentative d'ajout de l'opération : {}", operation.getNumOperation());
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, operation.getNumOperation());
            pstmt.setDate(2, java.sql.Date.valueOf(operation.getDateOperation())); 
            pstmt.setString(3, operation.getTypeOperation());
            pstmt.setFloat(4, operation.getMontant());
            pstmt.setInt(5, operation.getNumCompte());
            pstmt.executeUpdate();
        }
    }

    /**
     * Méthode pour ajouter un compte à un client
     * @param numCompte
     * @param numClient
     * @throws SQLException
     */
    public void ajouterCompteClient(int numCompte, int numClient) throws SQLException {
        String query = "INSERT INTO Compte_Client (numCompte, numClient) VALUES (?, ?)";
        String sqlCheck = "SELECT * FROM Compte_Client WHERE numCompte = ? AND numClient = ?";

        logger.debug("Tentative d'ajout de l'association compte-client : compte={}, client={}", numCompte, numClient);

        try {

            connection.setAutoCommit(false);

            if(obtenirCompteParNum(numCompte) == null) {
                throw new SQLException("Le compte avec le numéro " + numCompte + " n'existe pas.");
            }

            if(obtenirClientParNum(numClient) == null) {
                throw new SQLException("Le client avec le numéro " + numClient + " n'existe pas.");
            }

            // On vérifie si l'association existe déjà
            try(PreparedStatement pstmtCheck = connection.prepareStatement(sqlCheck)) {
                pstmtCheck.setInt(1, numCompte);
                pstmtCheck.setInt(2, numClient);
                ResultSet rs = pstmtCheck.executeQuery();
                if(rs.next()) {
                    throw new SQLException("L'association entre le compte " + numCompte + " et le client " + numClient + " existe déjà.");
                }
            }

            // Si tout est bon, on ajoute l'association
            try (PreparedStatement pstmt = connection.prepareStatement(query)) {
                pstmt.setInt(1, numCompte);
                pstmt.setInt(2, numClient);
                pstmt.executeUpdate();
            }

            // On commit la transaction
            connection.commit();

        } catch (SQLException e) {
            // En cas d'erreur, on rollback la transaction
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    /**
     * Méthode pour obtenir un client par son numero
     * @param numClient
     * @return Client
     * @throws SQLException
     */
    public Client obtenirClientParNum(int numClient) throws SQLException {
        logger.debug("Récupération d'un client pour le numéro {}", numClient);
        String query = "SELECT * FROM Client WHERE numClient = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numClient);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Client(
                        rs.getInt("numClient"),
                        rs.getString("nomClient"),
                        rs.getString("prenomClient"),
                        rs.getString("adClient"),
                        rs.getString("dateNaissClient"),
                        rs.getInt("ageClient"),
                        rs.getInt("numAgent")
                );
            } else {
                return null;
            }
        }
    }

    /** 
     * Méthode pour obtenir un agent par son numero
     * @param numAgent
     * @return Agent
     * @throws SQLException
     */
    public Agent obtenirAgentParNum(int numAgent) throws SQLException {
        logger.debug("Récupération d'un agent pour le numéro {}", numAgent);
        String query = "SELECT * FROM Agent WHERE numAgent = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numAgent);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Agent(
                        rs.getInt("numAgent"),
                        rs.getString("nomAgent"),
                        rs.getString("prenomAgent"),
                        rs.getBoolean("estDirecteur"),
                        rs.getInt("numAgence")
                );
            } else {
                return null;
            }
        }
    }

    /**
     * Méthode pour obtenir une agence par son numero
     * @param numAgence
     * @return Agence
     * @throws SQLException
     */
    public Agence obtenirAgenceParNum(int numAgence) throws SQLException {
        logger.debug("Récupération d'une agence pour le numéro {}", numAgence);
        String query = "SELECT * FROM Agence WHERE numAgence = ?";
        try(PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numAgence);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Agence(
                        rs.getInt("numAgence"),
                        rs.getString("telAgence"),
                        rs.getString("adAgence")
                );
            } else {
                return null;
            }
        }
    }



    /**
     * Méthode pour obtenir une operation par son numero
     * @param numOperation
     * @return Operation
     * @throws SQLException
     */
    public Operation obtenirOperationParNum(int numOperation) throws SQLException{
        logger.debug("Récupération d'une opération pour le numéro {}", numOperation);
        String query = "SELECT * FROM Operation WHERE numOperation = ?";
        try(PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numOperation);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Operation(
                        rs.getInt("numOperation"),
                        rs.getString("dateOperation"),
                        rs.getString("typeOperation"),
                        rs.getFloat("montant"),
                        rs.getInt("numCompte")
                );
            } else {
                return null;
            }
        }
    }


    /** 
     * Méthode pour obtenir les operations par compte
     * @param numCompte
     * @return List<Operation>
     * @throws SQLException
     */
    public List<Operation> obtenirOperationsParCompte(int numCompte) throws SQLException {
        logger.debug("Récupération des opérations pour le compte numéro {}", numCompte);
        String query = "SELECT * FROM Operation WHERE numCompte = ?";
        List<Operation> operations = new ArrayList<>();
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numCompte);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                operations.add(new Operation(
                        rs.getInt("numOperation"),
                        rs.getString("dateOperation"),
                        rs.getString("typeOperation"),
                        rs.getFloat("montant"),
                        rs.getInt("numCompte")
                ));
            }
        }
        return operations;
    }



    /** 
     * Méthode pour obtenir un compte par son numero
     * @param numCompte
     * @return Compte
     * @throws SQLException
     */
    public Compte obtenirCompteParNum(int numCompte) {
        logger.debug("Récupération d'un compte pour le numéro {}", numCompte);
        String query = "SELECT * FROM Compte WHERE numCompte = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numCompte);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Compte(
                        rs.getInt("numCompte"),
                        rs.getFloat("solde"),
                        rs.getString("typeCompte")
                );
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /** 
     * Méthode pour obtenir le solde d'un compte 
     * @param numCompte
     * @return float
     * @throws SQLException
     */
    public float obtenirSoldeCompte(int numCompte) throws SQLException {
        logger.debug("Obtention du solde pour le compte numéro {}", numCompte);
        String query = "SELECT solde FROM Compte WHERE numCompte = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numCompte);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getFloat("solde");
            } else {
                throw new SQLException("Compte non trouvé avec le numéro : " + numCompte);
            }
        }
    }

    /** 
     * Méthode pour obtenir le nombre de clients par agent
     * @param numAgent
     * @return int
     * @throws SQLException
     */ 
    public int obtenirNombreClientsParAgent(int numAgent) throws SQLException {
        logger.debug("Obtention du nombre de clients pour l'agent numéro {}", numAgent);
        String query = "SELECT COUNT(*) AS nombreClients FROM Client WHERE numAgent = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numAgent);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("nombreClients");
            } else {
                throw new SQLException("Erreur lors du comptage des clients pour l'agent numéro : " + numAgent);
            }
        }
    }


    /** 
     * Méthode pour obtenir les comptes d'un client
     * @param numClient
     * @return List<CompteClient>
     * @throws SQLException
     */
    public List<CompteClient> obtenirCompteParClient(int numClient) throws SQLException {
        logger.debug("Récupération des comptes pour le client numéro {}", numClient);
        String query = "SELECT * FROM Compte_Client WHERE numClient = ?";
        List<CompteClient> comptes = new ArrayList<>();
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, numClient);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int numCompte = rs.getInt("numCompte");
                int clientNum = rs.getInt("numClient");
                if (obtenirCompteParNum(numCompte) != null) {
                    comptes.add(new CompteClient(numCompte, clientNum));
                } else {
                    System.out.println("Compte avec le numéro " + numCompte + " n'existe pas.");
                }
            }
        }
        return comptes;
    }

    /** 
     * Méthode pour obtenir les comptes d'un client avec détails
     * @param numClient
     * @return List<Compte>
     * @throws SQLException
     * @return List<Compte>
     */
    public List<Compte> obtenirComptesParClient(int numClient) throws SQLException {
        logger.debug("Récupération des comptes détaillés pour le client numéro {}", numClient);
        String sql = """
            SELECT Compte.numCompte, Compte.solde, Compte.typeCompte
            FROM Compte
            JOIN Compte_Client ON Compte.numCompte = Compte_Client.numCompte
            WHERE Compte_Client.numClient = ?
        """;

        List<Compte> comptes = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, numClient);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                comptes.add(new Compte(
                        rs.getInt("numCompte"),
                        rs.getFloat("solde"),
                        rs.getString("typeCompte")
                ));
            }
        }

        return comptes;
    }
}



