package fr.iut.vannes.info.model;


/**
 * Classe Operation représentant une opération bancaire dans le système.
 * @author M.Weis
 * TP1 : JDBC
 * Groupe : C1
 */
public class Operation {

    private int numOperation;
    private String dateOperation;
    private String typeOperation;
    private float montant;
    private int numCompte;

    /**
     * Constructeur de la classe Operation.
     * @param numOperation
     * @param dateOperation
     * @param typeOperation
     * @param montant
     * @param numCompte
     */
    public Operation(int numOperation, String dateOperation, String typeOperation, float montant, int numCompte) {
        this.numOperation = numOperation;
        this.dateOperation = dateOperation;
        this.typeOperation = typeOperation;
        this.montant = montant;
        this.numCompte = numCompte;
    }

    // Getters et Setters

    /**
     * Getter pour le numéro de l'opération.
     * @return
     */
    public int getNumOperation() {
        return numOperation;
    }

    /**
     * Setter pour le numéro de l'opération.
     * @param numOperation
     */
    public void setNumOperation(int numOperation) {
        this.numOperation = numOperation;
    }

    /**
     * Getter pour la date de l'opération.
     * @return
     */
    public String getDateOperation() {
        return dateOperation;
    }

    /**
     * Setter pour la date de l'opération.
     * @param dateOperation
     */
    public void setDateOperation(String dateOperation) {
        this.dateOperation = dateOperation;
    }

    /**
     * Getter pour le type de l'opération.
     * @return
     */
    public String getTypeOperation() {
        return typeOperation;
    }

    /**
     * Setter pour le type de l'opération.
     * @param typeOperation
     */
    public void setTypeOperation(String typeOperation) {
        this.typeOperation = typeOperation;
    }

    /**
     * Getter pour le montant de l'opération.
     * @return
     */
    public float getMontant() {
        return montant;
    }

    /**
     * Setter pour le montant de l'opération.
     * @param montant
     */
    public void setMontant(float montant) {
        this.montant = montant;
    }

    /**
     * Getter pour le numéro du compte.
     * @return
     */
    public int getNumCompte() {
        return numCompte;
    }

    /**
     * Setter pour le numéro du compte.
     * @param numCompte
     */
    public void setNumCompte(int numCompte) {
        this.numCompte = numCompte;
    }
}
