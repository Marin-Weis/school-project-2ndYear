package fr.iut.vannes.info.test;

import fr.iut.vannes.info.dao.BanqueDAO;
import fr.iut.vannes.info.model.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Classe BanqueDAOTest pour tester les opérations de la base de données bancaire.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class BanqueDAOTest {

    private BanqueDAO dao;

    /**
     * Constructeur de la classe BanqueDAOTest.
     * @param connection
     */
    public BanqueDAOTest(Connection connection) {
        this.dao = new BanqueDAO(connection);
    }

    /**
     * Méthode pour réinitialiser la base de données en vidant toutes les tables.
     * @throws SQLException
     */
    public void resetDatabase() throws SQLException {
        Connection cnx = dao.getConnection();

        try (Statement stmt = cnx.createStatement()) {

            // On désactive les contraintes FK
            stmt.execute("SET session_replication_role = 'replica';");

            // On vide les tables dans l'ordre correct
            stmt.executeUpdate("DELETE FROM Operation;");
            stmt.executeUpdate("DELETE FROM Compte_Client;");
            stmt.executeUpdate("DELETE FROM Compte;");
            stmt.executeUpdate("DELETE FROM Client;");
            stmt.executeUpdate("DELETE FROM Agent;");
            stmt.executeUpdate("DELETE FROM Agence;");

            // On réactive les contraintes FK
            stmt.execute("SET session_replication_role = 'origin';");

            System.out.println("Base réinitialisée avec succès.");

        } catch (SQLException e) {
            System.out.println("Erreur resetDatabase : " + e.getMessage());
            throw e;
        }
    }

    /**
     * Tests des méthodes d'ajout avec gestion des exceptions
     */
    public void testAjouterAgence(Agence agence) {
        System.out.println("``` Test ajouterAgence ```");

        // Cas normal
        try {
            dao.ajouterAgence(agence);
            System.out.println("Ajout agence (normal) : OK");
        } catch (SQLException e) {
            System.out.println("Ajout agence (normal) : ERREUR -> " + e.getMessage());
        }

        // Cas d’erreur : même numéro d’agence → PK duplicate
        try {
            Agence agenceDoublon = new Agence(
                    agence.getNumAgence(), 
                    agence.getTelAgence(),
                    agence.getAdAgence()
            );
            dao.ajouterAgence(agenceDoublon);
            System.out.println("Ajout agence (doublon) : ECHEC (aurait dû échouer)");
        } catch (SQLException e) {
            System.out.println("Ajout agence (doublon) : OK (exception attendue)");
        }
    }

    /**
     * Tests des méthodes d'ajout avec gestion des exceptions
     * @param agent
     */
    public void testAjouterAgent(Agent agent) {
        System.out.println("``` Test ajouterAgent ```");

        // Cas normal
        try {
            dao.ajouterAgent(agent);
            System.out.println("Ajout agent (normal) : OK");
        } catch (SQLException e) {
            System.out.println("Ajout agent (normal) : ERREUR -> " + e.getMessage());
        }

        // Cas erreur : même numAgent 
        try {
            dao.ajouterAgent(agent);
            System.out.println("Ajout agent (doublon) : ECHEC");
        } catch (SQLException e) {
            System.out.println("Ajout agent (doublon) : OK (exception attendue)");
        }
    }

    /**
     * Tests des méthodes d'ajout avec gestion des exceptions
     * @param client
     */
    public void testAjouterClient(Client client) {
        System.out.println("``` Test ajouterClient ```");

        // Cas normal
        try {
            dao.ajouterClient(client);
            System.out.println("Ajout client (normal) : OK");
        } catch (SQLException e) {
            System.out.println("Ajout client (normal) : ERREUR -> " + e.getMessage());
        }

        // Cas erreur : âge invalide (via contrainte CHECK)
        try {
            Client jeune = new Client(
                    client.getNumClient() + 99,
                    client.getNomClient(),
                    client.getPrenomClient(),
                    client.getAdClient(),
                    client.getDateNaissClient(),
                    10,                      // âge invalide
                    client.getNumAgent()
            );
            dao.ajouterClient(jeune);
            System.out.println("Ajout client (âge invalide) : ECHEC");
        } catch (SQLException e) {
            System.out.println("Ajout client (âge invalide) : OK (exception attendue)");
        }
    }

    /**
     * Tests des méthodes d'ajout avec gestion des exceptions
     * @param compte
     */
    public void testAjouterCompte(Compte compte) {
        System.out.println("``` Test ajouterCompte ```");

        // Cas normal
        try {
            dao.ajouterCompte(compte);
            System.out.println("Ajout compte (normal) : OK");
        } catch (SQLException e) {
            System.out.println("Ajout compte (normal) : ERREUR -> " + e.getMessage());
        }

        // Cas erreur : solde négatif (CHECK solde >= 0)
        try {
            Compte compteNegatif = new Compte(
                    compte.getNumCompte() + 99,
                    -50,                 // solde invalide
                    compte.getTypeCompte()
            );
            dao.ajouterCompte(compteNegatif);
            System.out.println("Ajout compte (solde négatif) : ECHEC");
        } catch (SQLException e) {
            System.out.println("Ajout compte (solde négatif) : OK (exception attendue)");
        }
    }

    /**
     * Tests des méthodes d'ajout avec gestion des exceptions
     * @param op
     */
    public void testAjouterOperation(Operation op) {
        System.out.println("``` Test ajouterOperation ```");

        // Cas normal
        try {
            dao.ajouterOperation(op);
            System.out.println("Ajout operation (normal) : OK");
        } catch (SQLException e) {
            System.out.println("Ajout operation (normal) : ERREUR -> " + e.getMessage());
        }

        // Cas erreur : montant négatif (CHECK montant > 0)
        try {
            Operation opInvalid = new Operation(
                    op.getNumOperation() + 99,
                    op.getDateOperation(),
                    op.getTypeOperation(),
                    -10,                 // montant invalide
                    op.getNumCompte()
            );
            dao.ajouterOperation(opInvalid);
            System.out.println("Ajout operation (montant négatif) : ECHEC");
        } catch (SQLException e) {
            System.out.println("Ajout operation (montant négatif) : OK (exception attendue)");
        }
    }

    /**
     * Tests des méthodes d'ajout avec gestion des exceptions
     * @param numCompte
     * @param numClient
     */
    public void testAjouterCompteClient(int numCompte, int numClient) {
        System.out.println("``` Test ajouterCompteClient ```");

        // Cas normal
        try {
            dao.ajouterCompteClient(numCompte, numClient);
            System.out.println("Ajout association (normal) : OK");
        } catch (SQLException e) {
            System.out.println("Ajout association (normal) : ERREUR -> " + e.getMessage());
        }

        // Cas erreur : doublon
        try {
            dao.ajouterCompteClient(numCompte, numClient);
            System.out.println("Ajout association (doublon) : ECHEC");
        } catch (SQLException e) {
            System.out.println("Ajout association (doublon) : OK (exception attendue)");
        }
    }

}
