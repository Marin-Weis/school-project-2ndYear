package fr.iut.vannes.info;

import fr.iut.vannes.info.model.Agence;
import fr.iut.vannes.info.model.Agent;
import fr.iut.vannes.info.model.Client;
import fr.iut.vannes.info.model.Compte;
import fr.iut.vannes.info.model.Operation;

import java.sql.Connection;
import java.sql.SQLException;

import fr.iut.vannes.info.dao.BanqueDAO;
import fr.iut.vannes.info.test.BanqueDAOTest;

/**
 * Classe Main pour exécuter les tests de la base de données bancaire.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class Main {

    /**
     * Méthode pour attendre la disponibilité de la base de données PostgreSQL.
     * @return Connection
     */
    private static Connection waitForDB() {
        while (true) {
            try {
                System.out.println("Tentative de connexion à PostgreSQL...");
                Connection cnx = BanqueDAO.getConnection();
                System.out.println("Connexion à PostgreSQL réussie !");
                return cnx;
            } catch (Exception e) {
                System.out.println("Connexion échouée, nouvelle tentative dans 2 secondes...");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    /**
     * Point d'entrée principal de l'application avec les tests de la base de données.
     * @param args
     * @throws SQLException
     */
    public static void main(String[] args) throws SQLException {

        Connection connection = waitForDB();      //Connexion à la base de données postgreSQL établie
        BanqueDAOTest test = new BanqueDAOTest(connection);

        try {
            System.out.println("\n``` RESET BASE DE DONNÉES ``");
            test.resetDatabase();

            //Test Ajouter Agence
            Agence agence = new Agence(1, "0123456789", "123 Rue de la Banque");
            test.testAjouterAgence(agence);

            //Test Ajouter Agent
            Agent agent = new Agent(1, "Dupont", "Jean", true, 1);
            test.testAjouterAgent(agent);

            //Test Ajouter Client
            Client client = new Client(
                    1,
                    "Martin",
                    "Claire",
                    "4 Allée des campeurs",
                    "2006-01-01",
                    34,
                    1
            );
            test.testAjouterClient(client);

            //Test Ajouter Compte
            Compte compte = new Compte(1, 500.0f, "Courant");
            test.testAjouterCompte(compte);

            //Test Ajouter Opération
            Operation operation = new Operation(
                    1,
                    "2024-06-01",
                    "Virement",
                    150,
                    1
            );
            test.testAjouterOperation(operation);

            //Test Ajouter Compte_Client
            System.out.println("\n=== Test Ajouter Compte_Client ===");
            test.testAjouterCompteClient(1, 1);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("\n``` TESTS TERMINÉS ```");
    }
}
