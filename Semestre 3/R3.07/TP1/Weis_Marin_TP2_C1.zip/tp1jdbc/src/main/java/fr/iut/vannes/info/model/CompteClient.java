package fr.iut.vannes.info.model;

/**
 * Classe CompteClient représentant l'association entre un compte et un client.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class CompteClient {
    private int numCompte;
    private int numClient;

    /**
     * Constructeur de la classe CompteClient.
     * @param numCompte
     * @param numClient
     */
    public CompteClient(int numCompte, int numClient) {
        this.numCompte = numCompte;
        this.numClient = numClient;
    }

    //getters et setters

    /**
     * Getter pour le numéro du compte.
     * @return
     */
    public int getNumCompte() {
        return numCompte;
    }

    /**
     * Setter pour le numéro du compte.
     * @param numCompte
     */
    public void setNumCompte(int numCompte) {
        this.numCompte = numCompte;
    }

    /**
     * Getter pour le numéro du client.
     * @return
     */
    public int getNumClient() {
        return numClient;
    }

    /**
     * Setter pour le numéro du client.
     * @param numClient
     */
    public void setNumClient(int numClient) {
        this.numClient = numClient;
    }
}
