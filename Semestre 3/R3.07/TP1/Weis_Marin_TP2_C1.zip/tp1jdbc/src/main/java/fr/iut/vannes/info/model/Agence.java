package fr.iut.vannes.info.model;

/**
 * Classe Agence représentant une agence bancaire dans le système.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class Agence {

    private int numAgence;
    private String telAgence;
    private String adAgence;

    /**
     * Constructeur de la classe Agence.
     * @param numAgence
     * @param telAgence
     * @param adAgence
     */
    public Agence(int numAgence, String telAgence, String adAgence) {
        this.numAgence = numAgence;
        this.telAgence = telAgence;
        this.adAgence = adAgence;
    }

    // Getters et Setters

    /**
     * Getter pour le numéro de l'agence.
     * @return
     */
    public int getNumAgence() {
        return numAgence;
    }

    /**
     * Setter pour le numéro de l'agence.
     * @param numAgence
     */
    public void setNumAgence(int numAgence) {
        this.numAgence = numAgence;
    }

    public String getTelAgence() {
        return telAgence;
    }

    /**
     * Setter pour le téléphone de l'agence.
     * @param telAgence
     */
    public void setTelAgence(String telAgence) {
        this.telAgence = telAgence;
    }

    /**
     * Getter pour l'adresse de l'agence.
     * @return
     */
    public String getAdAgence() {
        return adAgence;
    }

    /**
     * Setter pour l'adresse de l'agence.
     * @param adAgence
     */
    public void setAdAgence(String adAgence) {
        this.adAgence = adAgence;
    }
}
