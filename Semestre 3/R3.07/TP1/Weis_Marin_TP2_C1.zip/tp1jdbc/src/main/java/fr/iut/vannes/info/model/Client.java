package fr.iut.vannes.info.model;


import java.util.Date;

/**
 * Classe Client représentant un client dans le système bancaire.
 * @author M.Weis
 * TP2 : JDBC
 * Groupe : C1
 */
public class Client {

    private int numClient;
    private String nomClient;
    private String prenomClient;
    private String adClient;
    private String dateNaissClient;
    private int ageClient;
    private int numAgent;

    /**
     * Constructeur de la classe Client.
     * @param numClient
     * @param nomClient
     * @param prenomClient
     * @param adClient
     * @param dateNaissClient
     * @param ageClient
     * @param numAgent
     */
    public Client(int numClient, String nomClient, String prenomClient, String adClient, String dateNaissClient, int ageClient, int numAgent) {
        this.numClient = numClient;
        this.nomClient = nomClient;
        this.prenomClient = prenomClient;
        this.adClient = adClient;
        this.dateNaissClient = dateNaissClient;
        this.ageClient = ageClient;
        this.numAgent = numAgent;
    }

    // Getters et Setters
    
    /**
     * Getter pour le numéro du client.
     * @return
     */
    public int getNumClient() {
        return numClient;
    }

    /**
     * Setter pour le numéro du client.
     * @param numClient
     */
    public void setNumClient(int numClient) {
        this.numClient = numClient;
    }

    /**
     * Getter pour le nom du client.
     * @return
     */
    public String getNomClient() {
        return nomClient;
    }

    /**
     * Setter pour le nom du client.
     * @param nomClient
     */
    public void setNomClient(String nomClient) {
        this.nomClient = nomClient;
    }

    /**
     * Getter pour le prénom du client.
     * @return
     */
    public String getPrenomClient() {
        return prenomClient;
    }

    /**
     * Setter pour le prénom du client.
     * @param prenomClient
     */
    public void setPrenomClient(String prenomClient) {
        this.prenomClient = prenomClient;
    }

    /**
     * Getter pour l'adresse du client.
     * @return
     */
    public String getAdClient() {
        return adClient;
    }

    /**
     * Setter pour l'adresse du client.
     * @param adClient
     */
    public void setAdClient(String adClient) {
        this.adClient = adClient;
    }

    /**
     * Getter pour la date de naissance du client.
     * @return
     */
    public String getDateNaissClient() {
        return dateNaissClient;
    }

    /**
     * Setter pour la date de naissance du client.
     * @param dateNaissClient
     */
    public void setDateNaissClient(String dateNaissClient) {
        this.dateNaissClient = dateNaissClient;
    }

    /**
     * Getter pour l'âge du client.
     * @return
     */
    public int getAgeClient() {
        return ageClient;
    }

    /**
     * Setter pour l'âge du client.
     * @param ageClient
     */
    public void setAgeClient(int ageClient) {
        this.ageClient = ageClient;
    }

    /**
     * Getter pour le numéro de l'agent associé au client.
     * @return
     */
    public int getNumAgent() {
        return numAgent;
    }

    /**
     * Setter pour le numéro de l'agent associé au client.
     * @param numAgent
     */
    public void setNumAgent(int numAgent) {
        this.numAgent = numAgent;
    }


}
