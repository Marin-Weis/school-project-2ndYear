/**
 * Auteur : Weis
 * Prénom : Marin
 * Groupe : C1
 */


interface PlayerStrategy {
    int takeTurn(int heapSize);
}
