
/**
 * Classe représentant un livre dans la bibliothèque.
 * @author Marin WEIS
 * BUT2 R2.04
 * TP2
 * Groupe C1
 */
public class Book {
    private String title;

    public Book(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
